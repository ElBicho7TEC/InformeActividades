<footer class="container-fluid bg-light">
    
                <div class="row justify-content-center text-center text-md-left">
                    <div class="col-12 col-md-4 mt-4 mt-md-0">
Pie de pagina
</div>
</div>

    </footer>



    <script src="js/jquery.slim.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>
